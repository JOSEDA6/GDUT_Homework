#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <limits.h>
#include <dirent.h>
#include <sys/stat.h>
#define MAXLINE 1024
#define MAX_HISTORY 100


extern int history_count;
extern char *history[MAX_HISTORY];

// cd2，整合之前相关代码逻辑
void cd2(int argc, char *argv[]) {
    if (argc > 1) {
        if (chdir(argv[1])!= 0) {
            perror("cd");
        }
    } else {
        char *home = getenv("HOME");
        if (home!= NULL) {
            if (chdir(home)!= 0) {
                perror("cd");
            }
        } else {
            fprintf(stderr, "HOME environment variable not set\n");
        }
    }
}

// pwd2，输出当前工作目录
void pwd2() {
    char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd))!= NULL) {
        printf("Your work path is %s\n", cwd);
    } else {
        perror("pwd2");
    }
}

// echo2，输出传入的参数内容
void echo2(int argc, char *argv[]) {
    for (int j = 1; j < argc; j++) {
        printf("%s ", argv[j]);
    }
    printf("\n");
}

// ls2，列出当前目录下的文件和目录
void ls2() {
    DIR *d;
    struct dirent *dir;
    d = opendir(".");
    if (d) {
        while ((dir = readdir(d))!= NULL) {
            printf("%s\n", dir->d_name);
        }
        closedir(d);
    } else {
        perror("ls2");
    }
}

// touch2，创建或更新文件
void touch2(int argc, char *argv[]) {
    for (int j = 1; j < argc; j++) {
        FILE *file = fopen(argv[j], "a");
        if (file) {
            fclose(file);
        } else {
            perror("touch2");
        }
    }
}

// cat2，读取并输出文件内容
void cat2(int argc, char *argv[]) {
    for (int j = 1; j < argc; j++) {
        FILE *file = fopen(argv[j], "r");
        if (file) {
            char line[MAXLINE];
            while (fgets(line, sizeof(line), file)) {
                printf("%s", line);
            }
            fclose(file);
        } else {
            perror("cat2");
        }
    }
}

// cp2，复制文件内容
void cp2(int argc, char *argv[]) {
    if (argc == 3) {
        FILE *src = fopen(argv[1], "r");
        FILE *dest = fopen(argv[2], "w");
        if (src && dest) {
            char line[MAXLINE];
            while (fgets(line, sizeof(line), src)) {
                fputs(line, dest);
            }
            fclose(src);
            fclose(dest);
        } else {
            perror("cp2");
        }
    } else {
        printf("Usage: cp2 source_file destination_file\n");
    }
}

// rm2，删除文件
void rm2(int argc, char *argv[]) {
    for (int j = 1; j < argc; j++) {
        if (remove(argv[j])!= 0) {
            perror("rm2");
        }
    }
}

// rename2
void rename2(int argc, char *argv[]) {
    if (argc == 3) {
        if (rename(argv[1], argv[2])!= 0) {
            perror("rename2");
        }
    } else {
        printf("Usage: rename2 old_name new_name\n");
    }
}



// history2，输出历史命令
void history2() {
    for (int i = 0; i < history_count; i++) {
        printf("%d %s\n", i + 1, history[i]);
    }
}

// quit函数，用于处理退出程序的功能
void quit(int argc, char *argv[]) {
    exit(0);
}

// record_error函数，用于记录不合法命令及错误信息到文件
void record_error(const char *command, const char *error_message) {
    // 获取主目录路径，这里简单使用 getenv("HOME") 获取，实际可能需要更多错误处理等
    char *home = getenv("HOME");
    if (home == NULL) {
        return;  // 如果获取失败，直接返回，也可以考虑更完善的错误处理逻辑
    }

    // 拼接完整的日志文件路径
    char log_path[PATH_MAX];
    snprintf(log_path, sizeof(log_path), "%s/.shelldemo_err.log", home);

    // 以追加模式打开文件
    FILE *fp = fopen(log_path, "a");
    if (fp == NULL) {
        return;  // 如果打开文件失败，直接返回，也可适当输出提示信息等
    }

    // 写入命令和错误信息到文件
    fprintf(fp, "Command: %s\nError Message: %s\n\n", command, error_message);

    // 关闭文件
    fclose(fp);
}

   int access_external_program(const char *command) {
       char *path = getenv("PATH");
       char *path_copy = strdup(path);
       char *dir = strtok(path_copy, ":");
       char full_path[PATH_MAX];
       int status;

       while (dir!= NULL) {
           snprintf(full_path, PATH_MAX, "%s/%s", dir, command);
           printf("Checking %s\n", full_path);
           if (access(full_path, X_OK) == 0) {
               pid_t pid = fork();
               if (pid == 0) {
                   // 子进程执行外部程序
                   execl(full_path, command, NULL);
                   // 如果 execl 失败，输出错误信息并退出子进程
                   perror("execl");
                   _exit(1);
               } else if (pid > 0) {
                   // 父进程等待子进程结束
                   waitpid(pid, &status, 0);
                   return status;
               } else {
                   perror("fork");
                   return -1;
               }
           }
           dir = strtok(NULL, ":");
       }
       free(path_copy);
       return -1;
   }

   int redirect_output(const char *command, const char *filename, int append) {
       pid_t pid = fork();
       if (pid == 0) {
           // 子进程处理重定向操作
           int flags = O_CREAT;
           if (append) {
               flags |= O_APPEND;
           } else {
               flags |= O_TRUNC;
           }
           flags |= O_WRONLY;
           int fd = open(filename, flags, 0644);
           if (fd == -1) {
               perror("open");
               _exit(1);
           }
           dup2(fd, 1);
           close(fd);
           // 执行命令
           execlp(command, command, NULL);
           perror("execlp");
           _exit(1);
       } else if (pid > 0) {
           // 父进程等待子进程结束
           int status;
           waitpid(pid, &status, 0);
           return status;
       } else {
           perror("fork");
           return -1;
       }
   }

      int my_pipe(const char *command1, const char *command2) {
       int pipefd[2];
       pid_t pid1, pid2;

       if (pipe(pipefd) == -1) {
           perror("pipe");
           return -1;
       }

       pid1 = fork();
       if (pid1 == 0) {
           // 子进程1：执行command1，并将输出写入管道
           close(pipefd[0]);  // 关闭读端
           dup2(pipefd[1], 1);  // 将标准输出重定向到管道写端
           close(pipefd[1]);
           execlp(command1, command1, NULL);
           perror("execlp1");
           _exit(1);
       } else if (pid1 > 0) {
           pid2 = fork();
           if (pid2 == 0) {
               // 子进程2：从管道读取输入并执行command2
               close(pipefd[1]);  // 关闭写端
               dup2(pipefd[0], 0);  // 将标准输入重定向到管道读端
               close(pipefd[0]);
               execlp(command2, command2, NULL);
               perror("execlp2");
               _exit(1);
           } else if (pid2 > 0) {
               // 父进程：关闭管道两端，等待子进程结束
               close(pipefd[0]);
               close(pipefd[1]);
               int status1, status2;
               waitpid(pid1, &status1, 0);
               waitpid(pid2, &status2, 0);
               return status1 + status2;
           } else {
               perror("fork2");
               return -1;
           }
       } else {
           perror("fork1");
           return -1;
       }
   }

