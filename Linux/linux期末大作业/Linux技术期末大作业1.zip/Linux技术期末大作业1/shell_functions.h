
#ifndef SHELL_FUNCTIONS_H
#define SHELL_FUNCTIONS_H

// 各个功能函数声明
void cd2(int argc, char *argv[]);
void pwd2();
void echo2(int argc, char *argv[]);
void ls2();
void touch2(int argc, char *argv[]);
void cat2(int argc, char *argv[]);
void cp2(int argc, char *argv[]);
void rm2(int argc, char *argv[]);
void rename2(int argc, char *argv[]);
void history2();
void quit(int argc, char *argv[]);

// 主函数中用到的其他函数声明（这里把相关辅助函数声明也放进来统一管理了，也可以根据实际情况拆分更合理些）
void print_welcome();
void print_prompt(const char *cwd);

// 用于记录不合法命令
void record_error(const char *command, const char *error_message);
//用于检查外部程序
int access_external_program(const char *command);
//重定向程序
int redirect_output(const char *command, const char *filename, int append);
//管道函数
int my_pipe(const char *command1, const char *command2);

#endif
